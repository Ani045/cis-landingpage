<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f7fa;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.thank-you-container {
    text-align: center;
    background-color: white;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 400px;
}

.thank-you-container h1 {
    font-size: 36px;
    color: #0CA854;
    margin-bottom: 20px;
}

.thank-you-container p {
    font-size: 18px;
    color: #333;
    margin-bottom: 40px;
}

.thank-you-container button {
    background-color: #0CA854;
    color: white;
    border: none;
    padding: 15px 30px;
    border-radius: 30px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.thank-you-container button:hover {
    background-color: #0CA854;
}

.thank-you-image {
    width: 300px; /* Adjust the size as needed */
    margin-bottom: 20px;
    border-radius: 10px;
}
@media only screen and (max-width: 600px) {
    .thank-you-image {
        width: 200px; 
  }
}

    </style>
    
    <!--Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-11468631248"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-11468631248');
    </script>
    
    <!-- Event snippet for DMT_Conversions_19/10/24 conversion page -->
    <script>
      gtag('event', 'conversion', {'send_to': 'AW-11468631248/L7f8CJ3nld8ZENDZ1dwq'});
    </script>

</head>
<body>
    <div class="thank-you-container">
        <img src="assets/thank-you.jpg" alt="Thank You" class="thank-you-image">
        <h1>THANK YOU</h1>
        <p>Thank You For Reaching Us. We Shall Get Back To You Shortly !!!</p>
        <button onclick="window.location.href='index'">BACK TO HOME</button>
    </div>
</body>
</html>
