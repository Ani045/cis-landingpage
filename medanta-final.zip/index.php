<!DOCTYPE html>
<html lang="en" dir="ltr" prefix="og: https://ogp.me/ns#">
  <head>
    
    <link
      rel="icon"
      href="assets/convicare-favicon.png"
      type="image/vnd.microsoft.icon"
    />

    <title>Convicare</title>
    <meta
      name="viewport"
      content="width=device-width, height=device-height, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0"
    />
    <link
      rel="stylesheet"
      media="all"
      href="sites/default/files/css/css_T7giGYAou_d3sTRfxY7Y5e0dDDUZt1yyeM7j5Rb4314.css"
    />
    <link
      rel="stylesheet"
      media="all"
      href="sites/default/files/css/css_i9_HzAxfI5IS3LCOrwh2P2n0K3puCQGz7pVOxd9hxUk.css"
    />
    <link
      rel="stylesheet"
      media="all"
      href="sites/default/files/css/css_7n5LVK7atgc0xzX05Em3V1j3bP-3O4Vk6LfbDH2IhcM.css"
    />
    <link
      rel="stylesheet"
      media="all"
      href="sites/default/files/css/css_eec6gWzpDnT9vQmzcBbx06txJ636h9JwBD7fOfQh_QU.css"
    />
    <link
      rel="stylesheet"
      media="all"
      href="sites/default/files/css/css_BbyBArMIxMrIsXBRyExjpC_SSis3qvsGeSw6b371YXc.css"
    />

    <script src="themes/custom/fortis/libs/defer.js"></script>

    <style>
        .submit-btn{
            gap:20px;
        }
        .mob-banner-text{
             display: none; 
        }
        .about-convicare-div{
            background: #fff;
            box-shadow: 0px 3px 26px #0000001C;
            border-radius: 8px;
            padding: 26px 32px 26px 32px;
            margin-top: 16px;
        }
        .about-convicare-div h1{
            font-size:24px;
        }
        .about-convicare-div-parent{
            margin-top:30px;
        }
        .international-page .international-header .international-main-header>div{
            align-items:center;
        }
        .fixed-bottom-bar{
                display:none;
            }
        @media only screen and (min-width: 600px) {
            .international-page .international-header .international-top-header{
                display:none;
            }
        }
        @media only screen and (max-width: 600px) {
            .fixed-bottom-bar{
                display:block;
            }
            .submit-btn{
                flex-direction: column;
                gap:0px;
            }
            
            .banner-section .banner-left .banner-text{
                backdrop-filter: blur(20px) !important;
                margin-top: 150px;
            }
            .banner-outer{
                /*margin-top: 10px;*/
            }
            .international-main-header{
                display:none;
            }
            .phone-wrap{
                margin-right: 10px;
            }
            .banner-section .banner-img>img, .banner-section .banner-img picture img{
                min-height: 350px;
            }
            .mob-banner-text{
                backdrop-filter: blur(20px) !important;
                background: rgba(255, 255, 255, .5);
                margin-top: 20px;
                 display: block; 
                border-radius: 8px;
                padding: 8px 42px 8px 11px;
                display: inline-block;
                background: rgba(255, 255, 255, 0.5);
            }
            .banner-text{
                 display: none !important; 
            }
            
            /* Fixed bottom bar styling */
.fixed-bottom-bar {
    position: fixed;
    bottom: 0;
    width: 100%;
    display: flex;
    justify-content: space-between;
    background-color: white;
    padding: 10px 0;
    box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
    z-index:999;
}

/* Buttons styling */
.help-button, .chat-button {
    width: 47%; /* Each button takes 48% width, leaving space for gap */
    padding: 10px 0;
    border: none;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.help-button {
    background-color: red;
    color: white;
    margin-left: 10px;
}

.chat-button {
    background-color: green;
    color: white;
    margin-right: 10px;
}

/* Ensure buttons adapt on smaller screens */
@media (max-width: 600px) {
    .help-button, .chat-button {
        font-size: 14px;
    }
}

}
    </style>
    
    <!--Start of Tawk.to Script-->
        <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/670f8b4b2480f5b4f58e256e/1iaabg8be';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
        })();
        </script>
    <!--End of Tawk.to Script-->
    
    <!--Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-11468631248"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-11468631248');
    </script>

  </head>

  <body class="international-page fortis-path-node">
    <a href="#main-content" class="visually-hidden focusable">
      Skip to main content
    </a>

    <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
      <!-- Site Top STARTS -->
      <!-- Site Top ENDS -->

      <!-- Header STARTS -->
      <!-- Header ENDS -->

      <!-- Header Top STARTS -->
      <!-- Header Top ENDS -->

      <!-- International Header STARTS -->
      <header class="international-header">
        <div class="international-top-header header-top-nav">
          <div>
            <div id="block-sitebranding-2" class="page-logo int-mobile-logo">
              <a href="/" rel="home">
                <img style="margin-top:10px" src="https://www.convicare.com/images/covicare-logo-1-1-min-oqa8jt5nw1lzjb0500f10bz3juopxz6ut7v2slau52.png" alt="Home" />
              </a>
              
            </div>
              <!--<a href="/" rel="home">-->
              <!--  <img style="max-width: 65px;" src="https://www.fortishealthcare.com/themes/custom/fortis/logo.png" alt="Home" />-->
              <!--</a>-->
            
            <div class="site-search-main" id="block-autocompletesearchform-2">
              <!--<div class="site-search">-->
              <!--  <img src="drupal-data/images/search-icon.svg" alt="search" />-->
              <!--</div>-->
              <div class="header-search-block">
                <form
                  class="autocomplete-search-form"
                  data-drupal-selector="autocomplete-search-form"
                  action="/search"
                  method="post"
                  id="autocomplete-search-form"
                  accept-charset="UTF-8"
                >
                  <div
                    class="js-form-item form-item js-form-type-textfield form-item-search js-form-item-search form-no-label"
                  >
                    <input
                      placeholder="Search for Doctors, Specialities and Hospitals"
                      class="global-search-field form-text"
                      autocomplete="off"
                      data-drupal-selector="global-search-auto"
                      type="text"
                      id="global-search-auto"
                      name="search"
                      value=""
                      size="50"
                      maxlength="128"
                    />
                  </div>
                  <div class="global-search-icon"></div>
                  <div class="global-search-close"></div>
                  <input
                    autocomplete="off"
                    data-drupal-selector="form-pobqfloqvhh85ofilfbozjlhcpavb7pi1r2scjeheku"
                    type="hidden"
                    name="form_build_id"
                    value="form-pObqflOqVHH85OFILfBOzJlHcpAvb7Pi1R2ScJEHEKU"
                  />
                  <input
                    data-drupal-selector="edit-autocomplete-search-form"
                    type="hidden"
                    name="form_id"
                    value="autocomplete_search_form"
                  />
                  <div
                    data-drupal-selector="edit-actions"
                    class="form-actions js-form-wrapper form-wrapper"
                    id="edit-actions--2"
                  >
                    <input
                      style="display: none"
                      data-drupal-selector="edit-submit"
                      type="submit"
                      id="edit-submit--2"
                      name="op"
                      value="Submit"
                      class="button js-form-submit form-submit"
                    />
                  </div>
                </form>
              </div>
            </div>
            <div
              class="views-element-container header_phone-int"
              id="block-views-block-international-faq-int-phone-num"
            >
              <div>
                <div
                  class="js-view-dom-id-7cac97a43bd0379f9f53e768f7a95111dbe70da15dc950fa91b49402851fbbdf"
                >
                  <div>
                    <div class="phone-wrap">
                      <!-- <div class="img">
                        <img
                          src="https://fhltothenewwebuat.blob.core.windows.netdrupal-data/inline-images/Icon%20simple-whatsapp.png"
                        />
                      </div> -->
                      <div class="text">
                          <img style="max-width:22px;margin-right: 10px;" src="assets/whatsapp-icon.png" alt="search" />
                        <a href="https://api.whatsapp.com/send?phone=919990007484&text=Hello%2C%20I%E2%80%99m%20planning%20medical%20travel%20to%20India%20and%20would%20like%20to%20know%20more%20about%20treatment%20options%20at%20Medanta%20Hospital.%20Could%20you%20assist%20me%3F">+91 99900 07484</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="international-main-header">
          <div>
            <div id="block-sitebranding" class="page-logo">
              <a href="/" rel="home">
                <img src="https://www.convicare.com/images/covicare-logo-1-1-min-oqa8jt5nw1lzjb0500f10bz3juopxz6ut7v2slau52.png" alt="Home" />
              </a>
              <!--<a href="/" rel="home">-->
              <!--  <img style="margin-top: -7px;" src="https://www.fortishealthcare.com/themes/custom/fortis/logo.png" alt="Home" />-->
              <!--</a>-->
            </div>
            <div class="text" style="display:flex">
                    <div>
                        <img style="max-width:22px;margin-right: 10px;" src="assets/whatsapp-icon.png" alt="search" />
                        
                    </div>
                        <a style="color: #db7c65;font-size:18px;font-weight:bold;font-family:"Montserrat", sans-serif;text-decoration: underline;" href="https://api.whatsapp.com/send?phone=919990007484&text=Hello%2C%20I%E2%80%99m%20planning%20medical%20travel%20to%20India%20and%20would%20like%20to%20know%20more%20about%20treatment%20options%20at%20Medanta%20Hospital.%20Could%20you%20assist%20me%3F">+91 99900 07484</a>
                      </div>
            
          </div>
        </div>
      </header>
      <!-- International Header ENDS -->

      <main>
        <!-- Banner STARTS -->
        <div class="banner-outer">
          <div>
            <div
              class="views-element-container"
              id="block-views-block-banner-content-block-1"
            >
              <div>
                <div
                  class="js-view-dom-id-aabf09984bd922a587580ad8a3e7b6da397dc01222b8d8056569c36b7f791591"
                >
                  <div class="views-row">
                    <div
                      class="views-field views-field-banner-responsive-image"
                    >
                      <span class="field-content"
                        ><div class="banner-section">
                          <div class="banner-img">
                            <picture>
                              <source media="(max-width:767px)" srcset="" />
                              <img
                                src="assets/Medanta-hospital.webp"
                              />
                            </picture>
                          </div>
                          <div class="banner-content">
                            <div class="wrapper">
                              <div class="banner-left">
                                <div class="banner-text">
                                  <h1>
                                    Medanta - The Medicity
                                  </h1>
                                  <p>
                                    Medanta - The Medicity is one of India's largest multi-super specialty institutes located in Gurgaon, a bustling town near the National Capital Region. Known for our commitment to the highest standards of medical care, we offer a seamless healthcare experience for international patients from around the globe.
                                  </p>
                                </div>
                              </div>
                              <div class="banner-right"></div>
                            </div>
                          </div></div
                      ></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Banner ENDS -->

        <!-- Breadcrumbs STARTS -->
        <!-- Breadcrumbs ENDS -->

        <!-- Page Top STARTS -->
        <!-- Page Top ENDS -->

        <!-- Content STARTS -->
        
        <div class="mob-banner-text">
          <h1>
            Medanta - The Medicity
          </h1>
          <p>Medanta - The Medicity is one of India's largest multi-super specialty institutes located in Gurgaon, a bustling town near the National Capital Region. Known for our commitment to the highest standards of medical care, we offer a seamless healthcare experience for international patients from around the globe.</p>
        </div>
        
        <div class="wrapper about-convicare-div-parent">
            <div class="about-convicare-div">
                <h1>Welcome to Convicare</h1>
          <p>
            At Convicare, we excel in providing comprehensive medical tourism services tailored to meet the needs of international patients seeking surgical and medical treatments in India. Based in the thriving healthcare cities of Delhi and Gurgaon, we connect patients from Africa, Southeast Asia, and the Middle East with some of India’s premier medical institutions.
          </p>
            </div>
        </div>
                                
                                
        <div>
          <div data-drupal-messages-fallback class="hidden"></div>
          <div id="block-hotfixes">
            <div class="layout layout--onecol">
              <div class="layout__region layout__region--content">
                <div>
                  <style>
                    /*--><![CDATA[/* ><!--*/

                    .table-img-text {
                      table-layout: fixed;
                    }

                    /*--><!]]>*/
                  </style>
                </div>
              </div>
            </div>
          </div>
          <div id="block-fortis-content">
            <div class="international-outer">
              <div class="wrapper">
                <div class="views-element-container">
                  <div
                    class="int-number-view section-empty js-view-dom-id-255f21e20c04314559b5729c3c034cbc22599101fbe4a03730d643b723eccdfd"
                  >
                    <div class="item-list">
                      <ul class="international-number-list">
                        <li>
                          <div class="icon">
                            <img
                              src="drupal-data/2023-05/Group%2022830%20%284%29.svg"
                              alt="img"
                              loading="lazy"
                            />
                          </div>
                          <div class="text-wrap">
                            <div class="title">27</div>
                            <div class="des">Hospitals across the Country</div>
                          </div>
                        </li>
                        <li>
                          <div class="icon">
                            <img
                              src="drupal-data/2023-05/Group%2022832%20%284%29.svg"
                              alt="img"
                              loading="lazy"
                            />
                          </div>
                          <div class="text-wrap">
                            <div class="title">4,300+</div>
                            <div class="des">Operational Beds</div>
                          </div>
                        </li>
                        <li>
                          <div class="icon">
                            <img
                              src="drupal-data/2023-05/Group%2022467%20%286%29.svg"
                              alt="img"
                              loading="lazy"
                            />
                          </div>
                          <div class="text-wrap">
                            <div class="title">200,000+</div>
                            <div class="des">
                              International Patients Treated
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="icon">
                            <img
                              src="drupal-data/2023-05/Group%2022897%20%285%29.svg"
                              alt="img"
                              loading="lazy"
                            />
                          </div>
                          <div class="text-wrap">
                            <div class="title">175+</div>
                            <div class="des">
                              Countries covered across the globe
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="icon">
                            <img
                              src="drupal-data/2023-05/Group%2022475%20%285%29.svg"
                              alt="img"
                              loading="lazy"
                            />
                          </div>
                          <div class="text-wrap">
                            <div class="title">20+</div>
                            <div class="des">International Govt. Tie-ups</div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div class="get-an-estimate">
                  <form id="contact-form" class="get-an-estimate-form" accept-charset='UTF-8' action='https://app.formester.com/forms/d791f818-d8c1-4f38-8ee8-0667ed602bd5/submissions' method='POST'>
                    <h2 class="heading2">
                      Get a personalised treatment plan and estimate
                    </h2>
                    <div class="first-wrap">
                      <div
                        class="js-form-item form-item js-form-type-textfield form-item-int-name js-form-item-int-name"
                      >
                        <label class="form-required" for="edit-int-name"
                          >Name of the Patient</label
                        >
                        <input
                          data-drupal-selector="edit-int-name"
                          type="text"
                          id="edit-int-name"
                          name="patientName"
                          value=""
                          size="60"
                          maxlength="40"
                          class="form-text"
                          required
                        />
                      </div>
                      <div
                        class="js-form-item form-item js-form-type-tel form-item-age js-form-item-age"
                      >
                        <label
                          for="edit-age"
                          >Age</label
                        >
                        <input
                          data-drupal-selector="edit-age"
                          type="tel"
                          id="edit-age"
                          name="PatientAge"
                          value=""
                          size="30"
                          maxlength="3"
                          class="form-tel required"
                        />
                      </div>
                      <div
                        class="js-form-item form-item js-form-type-select form-item-gender js-form-item-gender"
                      >
                        <label for="edit-gender"
                          >Gender</label
                        >
                        <select
                          data-drupal-selector="edit-gender"
                          id="edit-gender"
                          name="gender"
                          class="form-select"
                        >
                          <option value="0">Select Gender</option>
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                        </select>
                      </div>
                    </div>
                    <div class="second-wrap">
                      <div
                        class="js-form-item form-item js-form-type-tel form-item-int-country-code js-form-item-int-country-code"
                      >
                        <label class="form-required" for="edit-int-country-code"
                          >Country Code</label
                        >
                        <input
                          data-drupal-selector="edit-int-country-code"
                          type="tel"
                          id="edit-int-country-code"
                          name="countryCode"
                          value=""
                          size="30"
                          maxlength="5"
                          class="form-tel"
                          required
                        />
                      </div>
                      <div
                        class="js-form-item form-item js-form-type-tel form-item-int-mobile-number js-form-item-int-mobile-number"
                      >
                        <label
                          class="form-required"
                          for="edit-int-mobile-number"
                          >Contact No</label
                        >
                        <input
                          data-drupal-selector="edit-int-mobile-number"
                          type="tel"
                          id="edit-int-mobile-number"
                          name="patientNumber"
                          value=""
                          size="30"
                          maxlength="128"
                          class="form-tel"
                          oninput="limitNumberLength(this, 9+1)"
                          required
                        />
                      </div>
                      <div
                        class="js-form-item form-item js-form-type-select form-item-country js-form-item-country"
                      >
                        <label class="form-required" for="edit-country"
                          >Country</label
                        >
                        <select
                          data-drupal-selector="edit-country"
                          id="edit-country"
                          name="country"
                          class="form-select"
                        >
                          <option value="0">Please select Country</option>
                          <option value="AF">Afghanistan</option>
                          <option value="AL">Albania</option>
                          <option value="DZ">Algeria</option>
                          <option value="AS">American Samoa</option>
                          <option value="AD">Andorra</option>
                          <option value="AO">Angola</option>
                          <option value="AI">Anguilla</option>
                          <option value="AQ">Antarctica</option>
                          <option value="AG">Antigua & Barbuda</option>
                          <option value="AR">Argentina</option>
                          <option value="AM">Armenia</option>
                          <option value="AW">Aruba</option>
                          <option value="AC">Ascension Island</option>
                          <option value="AU">Australia</option>
                          <option value="AT">Austria</option>
                          <option value="AZ">Azerbaijan</option>
                          <option value="BS">Bahamas</option>
                          <option value="BH">Bahrain</option>
                          <option value="BD">Bangladesh</option>
                          <option value="BB">Barbados</option>
                          <option value="BY">Belarus</option>
                          <option value="BE">Belgium</option>
                          <option value="BZ">Belize</option>
                          <option value="BJ">Benin</option>
                          <option value="BM">Bermuda</option>
                          <option value="BT">Bhutan</option>
                          <option value="BO">Bolivia</option>
                          <option value="BA">Bosnia & Herzegovina</option>
                          <option value="BW">Botswana</option>
                          <option value="BV">Bouvet Island</option>
                          <option value="BR">Brazil</option>
                          <option value="IO">
                            British Indian Ocean Territory
                          </option>
                          <option value="VG">British Virgin Islands</option>
                          <option value="BN">Brunei</option>
                          <option value="BG">Bulgaria</option>
                          <option value="BF">Burkina Faso</option>
                          <option value="BI">Burundi</option>
                          <option value="KH">Cambodia</option>
                          <option value="CM">Cameroon</option>
                          <option value="CA">Canada</option>
                          <option value="IC">Canary Islands</option>
                          <option value="CV">Cape Verde</option>
                          <option value="BQ">Caribbean Netherlands</option>
                          <option value="KY">Cayman Islands</option>
                          <option value="CF">Central African Republic</option>
                          <option value="EA">Ceuta & Melilla</option>
                          <option value="TD">Chad</option>
                          <option value="CL">Chile</option>
                          <option value="CN">China</option>
                          <option value="CX">Christmas Island</option>
                          <option value="CP">Clipperton Island</option>
                          <option value="CC">Cocos (Keeling) Islands</option>
                          <option value="CO">Colombia</option>
                          <option value="KM">Comoros</option>
                          <option value="CG">Congo - Brazzaville</option>
                          <option value="CD">Congo - Kinshasa</option>
                          <option value="CK">Cook Islands</option>
                          <option value="CR">Costa Rica</option>
                          <option value="HR">Croatia</option>
                          <option value="CU">Cuba</option>
                          <option value="CW">Curaçao</option>
                          <option value="CY">Cyprus</option>
                          <option value="CZ">Czechia</option>
                          <option value="CI">Côte d’Ivoire</option>
                          <option value="DK">Denmark</option>
                          <option value="DG">Diego Garcia</option>
                          <option value="DJ">Djibouti</option>
                          <option value="DM">Dominica</option>
                          <option value="DO">Dominican Republic</option>
                          <option value="EC">Ecuador</option>
                          <option value="EG">Egypt</option>
                          <option value="SV">El Salvador</option>
                          <option value="GQ">Equatorial Guinea</option>
                          <option value="ER">Eritrea</option>
                          <option value="EE">Estonia</option>
                          <option value="SZ">Eswatini</option>
                          <option value="ET">Ethiopia</option>
                          <option value="FK">Falkland Islands</option>
                          <option value="FO">Faroe Islands</option>
                          <option value="FJ">Fiji</option>
                          <option value="FI">Finland</option>
                          <option value="FR">France</option>
                          <option value="GF">French Guiana</option>
                          <option value="PF">French Polynesia</option>
                          <option value="TF">
                            French Southern Territories
                          </option>
                          <option value="GA">Gabon</option>
                          <option value="GM">Gambia</option>
                          <option value="GE">Georgia</option>
                          <option value="DE">Germany</option>
                          <option value="GH">Ghana</option>
                          <option value="GI">Gibraltar</option>
                          <option value="GR">Greece</option>
                          <option value="GL">Greenland</option>
                          <option value="GD">Grenada</option>
                          <option value="GP">Guadeloupe</option>
                          <option value="GU">Guam</option>
                          <option value="GT">Guatemala</option>
                          <option value="GG">Guernsey</option>
                          <option value="GN">Guinea</option>
                          <option value="GW">Guinea-Bissau</option>
                          <option value="GY">Guyana</option>
                          <option value="HT">Haiti</option>
                          <option value="HM">Heard & McDonald Islands</option>
                          <option value="HN">Honduras</option>
                          <option value="HK">Hong Kong SAR China</option>
                          <option value="HU">Hungary</option>
                          <option value="IS">Iceland</option>
                          <option value="IN">India</option>
                          <option value="ID">Indonesia</option>
                          <option value="IR">Iran</option>
                          <option value="IQ">Iraq</option>
                          <option value="IE">Ireland</option>
                          <option value="IM">Isle of Man</option>
                          <option value="IL">Israel</option>
                          <option value="IT">Italy</option>
                          <option value="JM">Jamaica</option>
                          <option value="JP">Japan</option>
                          <option value="JE">Jersey</option>
                          <option value="JO">Jordan</option>
                          <option value="KZ">Kazakhstan</option>
                          <option value="KE">Kenya</option>
                          <option value="KI">Kiribati</option>
                          <option value="XK">Kosovo</option>
                          <option value="KW">Kuwait</option>
                          <option value="KG">Kyrgyzstan</option>
                          <option value="LA">Laos</option>
                          <option value="LV">Latvia</option>
                          <option value="LB">Lebanon</option>
                          <option value="LS">Lesotho</option>
                          <option value="LR">Liberia</option>
                          <option value="LY">Libya</option>
                          <option value="LI">Liechtenstein</option>
                          <option value="LT">Lithuania</option>
                          <option value="LU">Luxembourg</option>
                          <option value="MO">Macao SAR China</option>
                          <option value="MG">Madagascar</option>
                          <option value="MW">Malawi</option>
                          <option value="MY">Malaysia</option>
                          <option value="MV">Maldives</option>
                          <option value="ML">Mali</option>
                          <option value="MT">Malta</option>
                          <option value="MH">Marshall Islands</option>
                          <option value="MQ">Martinique</option>
                          <option value="MR">Mauritania</option>
                          <option value="MU">Mauritius</option>
                          <option value="YT">Mayotte</option>
                          <option value="MX">Mexico</option>
                          <option value="FM">Micronesia</option>
                          <option value="MD">Moldova</option>
                          <option value="MC">Monaco</option>
                          <option value="MN">Mongolia</option>
                          <option value="ME">Montenegro</option>
                          <option value="MS">Montserrat</option>
                          <option value="MA">Morocco</option>
                          <option value="MZ">Mozambique</option>
                          <option value="MM">Myanmar (Burma)</option>
                          <option value="NA">Namibia</option>
                          <option value="NR">Nauru</option>
                          <option value="NP">Nepal</option>
                          <option value="NL">Netherlands</option>
                          <option value="AN">Netherlands Antilles</option>
                          <option value="NC">New Caledonia</option>
                          <option value="NZ">New Zealand</option>
                          <option value="NI">Nicaragua</option>
                          <option value="NE">Niger</option>
                          <option value="NG">Nigeria</option>
                          <option value="NU">Niue</option>
                          <option value="NF">Norfolk Island</option>
                          <option value="MP">Northern Mariana Islands</option>
                          <option value="KP">North Korea</option>
                          <option value="MK">North Macedonia</option>
                          <option value="NO">Norway</option>
                          <option value="OM">Oman</option>
                          <option value="QO">Outlying Oceania</option>
                          <option value="PK">Pakistan</option>
                          <option value="PW">Palau</option>
                          <option value="PS">Palestinian Territories</option>
                          <option value="PA">Panama</option>
                          <option value="PG">Papua New Guinea</option>
                          <option value="PY">Paraguay</option>
                          <option value="PE">Peru</option>
                          <option value="PH">Philippines</option>
                          <option value="PN">Pitcairn Islands</option>
                          <option value="PL">Poland</option>
                          <option value="PT">Portugal</option>
                          <option value="PR">Puerto Rico</option>
                          <option value="QA">Qatar</option>
                          <option value="RO">Romania</option>
                          <option value="RU">Russia</option>
                          <option value="RW">Rwanda</option>
                          <option value="RE">Réunion</option>
                          <option value="WS">Samoa</option>
                          <option value="SM">San Marino</option>
                          <option value="SA">Saudi Arabia</option>
                          <option value="SN">Senegal</option>
                          <option value="RS">Serbia</option>
                          <option value="SC">Seychelles</option>
                          <option value="SL">Sierra Leone</option>
                          <option value="SG">Singapore</option>
                          <option value="SX">Sint Maarten</option>
                          <option value="SK">Slovakia</option>
                          <option value="SI">Slovenia</option>
                          <option value="SB">Solomon Islands</option>
                          <option value="SO">Somalia</option>
                          <option value="ZA">South Africa</option>
                          <option value="GS">
                            South Georgia & South Sandwich Islands
                          </option>
                          <option value="KR">South Korea</option>
                          <option value="SS">South Sudan</option>
                          <option value="ES">Spain</option>
                          <option value="LK">Sri Lanka</option>
                          <option value="BL">St. Barthélemy</option>
                          <option value="SH">St. Helena</option>
                          <option value="KN">St. Kitts & Nevis</option>
                          <option value="LC">St. Lucia</option>
                          <option value="MF">St. Martin</option>
                          <option value="PM">St. Pierre & Miquelon</option>
                          <option value="VC">St. Vincent & Grenadines</option>
                          <option value="SD">Sudan</option>
                          <option value="SR">Suriname</option>
                          <option value="SJ">Svalbard & Jan Mayen</option>
                          <option value="SE">Sweden</option>
                          <option value="CH">Switzerland</option>
                          <option value="SY">Syria</option>
                          <option value="ST">São Tomé & Príncipe</option>
                          <option value="TW">Taiwan</option>
                          <option value="TJ">Tajikistan</option>
                          <option value="TZ">Tanzania</option>
                          <option value="TH">Thailand</option>
                          <option value="TL">Timor-Leste</option>
                          <option value="TG">Togo</option>
                          <option value="TK">Tokelau</option>
                          <option value="TO">Tonga</option>
                          <option value="TT">Trinidad & Tobago</option>
                          <option value="TA">Tristan da Cunha</option>
                          <option value="TN">Tunisia</option>
                          <option value="TR">Turkey</option>
                          <option value="TM">Turkmenistan</option>
                          <option value="TC">Turks & Caicos Islands</option>
                          <option value="TV">Tuvalu</option>
                          <option value="UM">U.S. Outlying Islands</option>
                          <option value="VI">U.S. Virgin Islands</option>
                          <option value="UG">Uganda</option>
                          <option value="UA">Ukraine</option>
                          <option value="AE">United Arab Emirates</option>
                          <option value="GB">United Kingdom</option>
                          <option value="US">United States</option>
                          <option value="UY">Uruguay</option>
                          <option value="UZ">Uzbekistan</option>
                          <option value="VU">Vanuatu</option>
                          <option value="VA">Vatican City</option>
                          <option value="VE">Venezuela</option>
                          <option value="VN">Vietnam</option>
                          <option value="WF">Wallis & Futuna</option>
                          <option value="EH">Western Sahara</option>
                          <option value="YE">Yemen</option>
                          <option value="ZM">Zambia</option>
                          <option value="ZW">Zimbabwe</option>
                          <option value="AX">Åland Islands</option>
                        </select>
                      </div>
                    </div>
                    
                    
                    <fieldset
                      data-drupal-selector="edit-feedback-wrapper"
                      id="edit-feedback-wrapper"
                      class="js-form-item form-item js-form-wrapper form-wrapper"
                    >
                      <legend>
                        <span class="fieldset-legend"></span>
                      </legend>
                      <div class="fieldset-wrapper">
                        <div class="wrap-feedback">
                          <div
                            class="js-form-item form-item js-form-type-textarea form-item-feedback js-form-item-feedback"
                          >
                            <label for="edit-feedback--2">Your Message</label>
                            <div>
                              <textarea
                                data-drupal-selector="edit-feedback"
                                id="edit-feedback--2"
                                name="message"
                                rows="5"
                                cols="60"
                                class="form-textarea"
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                    </fieldset>
                    <div class="submit-btn">
                        <button class="button" type="submit">Get An Estimate</button>
                      <!--<input-->
                      <!--  data-drupal-selector="edit-submit"-->
                      <!--  type="submit"-->
                      <!--  id="edit-submit"-->
                      <!--  name="op"-->
                      <!--  value="Get An Estimate"-->
                      <!--  class="button js-form-submit form-submit"-->
                      <!--/>-->
                      <div class="submit-btn-text">
                        
                        
                        <div class="dis">
                          <strong>Disclaimer:</strong> This is an indicative
                          cost based on the reports/ information shared with us.
                          Final estimate will be shared once patient is
                          physically evaluated.
                        </div>
                      </div>
                      
                      <input
                        data-drupal-selector="edit-get-an-estimate-form"
                        type="hidden"
                        name="form_id"
                        value="get_an_estimate_form"
                      />
                      <div class="messages-status"></div>
                    </div>
                  </form>
                </div>
                <div class="views-element-container">
                  <div
                    class="speciality-block int-speciality-block section-empty js-view-dom-id-954a3005fb8901d98b54d5438c0761bf0e4595d22d87b7459a395b41b25b9a8f"
                  >
                    <header>
                      <h3 class="heading2">
                        Medanta International Patient Care Services
                      </h3>
                    </header>

                    <div class="item-list">
                      <ul class="speciality-card-slider">
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/cardiac-sciences-5"
                                ><img
                                  src="drupal-data/2023-03/Cardiology.svg"
                                />
                                <span class="spec-name"
                                  >Cardiac Sciences</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/medical-oncology-5"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Medical Oncology</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/radiation-oncology-9"
                                ><img
                                  src="drupal-data/2024-09/Radiation%20Oncology.svg"
                                />
                                <span class="spec-name"
                                  >Radiation Oncology</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/surgical-oncology-10"
                                ><img
                                  src="drupal-data/2024-09/Surgical%20Oncology.svg"
                                />
                                <span class="spec-name"
                                  >Surgical Oncology</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/ent-12"
                                ><img src="drupal-data/2023-03/ENT.svg" />
                                <span class="spec-name">ENT</span></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/gastroenterology-50"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Gastroenterology</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/bowel-transplant-109"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Bowel Transplant</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/haematology-and-bmt-112"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Haematology and BMT</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/heart-transplant-75"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Heart Transplant</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/kidney-transplant-3-0"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Kidney Transplant</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/liver-transplant-4"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Liver Transplant</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/lung-transplant-111"
                                ><img
                                  src="drupal-data/images/speciality.png"
                                />
                                <span class="spec-name"
                                  >Lung Transplant</span
                                ></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/urology-29"
                                ><img src="drupal-data/2023-03/Urology.svg" />
                                <span class="spec-name">Urology</span></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/orthopaedics-14"
                                ><img
                                  src="drupal-data/2023-03/Orthopaedics.svg"
                                />
                                <span class="spec-name">Orthopaedics</span></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/paediatrics-10"
                                ><img
                                  src="drupal-data/2023-03/Paediatrics.svg"
                                />
                                <span class="spec-name">Paediatrics</span></a
                              >
                            </span>
                          </div>
                        </li>
                        <li>
                          <div class="views-field views-field-name">
                            <span class="field-content"
                              ><a href="/specialities/pulmonology-6"
                                ><img
                                  src="drupal-data/2023-03/Pulmonology.svg"
                                />
                                <span class="spec-name">Pulmonology</span></a
                              >
                            </span>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div class="medical-procedures">
                  <div class="views-element-container">
                    <div
                      class="section-empty int-medical-procedure js-view-dom-id-5ca0c6970e41ac3a02bf86be7acd9147029f39244de53b575556dd1d2c625285"
                    >
                      <div
                        class="section-empty int-medical-procedure js-view-dom-id-ca941073125ff49ba23047f39fcf3607497f25c678f99e88b9150a8ca0073991"
                      ></div>
                    </div>
                  </div>
                </div>
                

                <div class="patient-services">
                  <div class="head-wrap">
                    <h2 class="heading2">
                      Healthcare Services for International Patients
                    </h2>
                    <div class="sub-text">
                      At Medanta, we cater to a diverse global patient base,
                      ensuring that every patient receives personalized and
                      culturally sensitive medical care. We offer a wide range
                      of specialized medical services in a world-class
                      healthcare setting.
                    </div>
                  </div>
                  <div class="views-element-container">
                    <div
                      class="section-empty js-view-dom-id-3b96531a79938d2915cf39667e836666b05b81864eeb34fbb1da20a92b18fe1f"
                    >
                      <div class="item-list">
                        <ul class="patient-services-list">
                          <li>
                            <div class="text">
                              Get a personalized treatment plan and estimate
                            </div>
                            <div class="icon">
                              <img
                                src="https://www.fortishealthcare.com/drupal-data/2023-05/cost%20%285%29.svg"
                                alt="img"
                                loading="lazy"
                              />
                            </div>
                          </li>
                          <li>
                            <div class="text">Visa assistance</div>
                            <div class="icon">
                              <img
                                src="https://www.fortishealthcare.com/drupal-data/2023-05/credit-card%20%2811%29.svg"
                                alt="img"
                                loading="lazy"
                              />
                            </div>
                          </li>
                          <li>
                            <div class="text">Airport Pickup and Drop</div>
                            <div class="icon">
                              <img
                                src="https://www.fortishealthcare.com/drupal-data/styles/search_autocomplete/azblob/2024-03/288-2881801_airport-transfers-chauffeur-services-parking-icon.png?itok=nPnmRcPy"
                                width="50"
                                height="50"
                                alt="img"
                                loading="lazy"
                              />
                            </div>
                          </li>
                          <li>
                            <div class="text">Relationship Manager</div>
                            <div class="icon">
                              <img
                                src="https://www.fortishealthcare.com/drupal-data/2023-05/Group%2022934%20%285%29.svg"
                                alt="img"
                                loading="lazy"
                              />
                            </div>
                          </li>
                          <li>
                            <div class="text">Accommodation & Food</div>
                            <div class="icon">
                              <img
                                src="https://www.fortishealthcare.com/drupal-data/2023-05/Group%2022935%20%284%29.svg"
                                alt="img"
                                loading="lazy"
                              />
                            </div>
                          </li>
                          <li>
                            <div class="text">
                              Discharge, Departure & Post-Hospitalization Care
                            </div>
                            <div class="icon">
                              <img
                                src="https://www.fortishealthcare.com/drupal-data/styles/search_autocomplete/azblob/2024-03/Discharge%20Departure%20%26%20Post%20hopsitalization%20care.png?itok=BVUV3UEA"
                                width="50"
                                height="50"
                                alt="img"
                                loading="lazy"
                              />
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="plan-guidelines-wrap">
                  <div class="plan-a-trip">
                    <div class="head-wrap"></div>
                    <div class="views-element-container">
                      <div
                        class="plan-trip-view section-empty js-view-dom-id-e5f081e81f44581090d9b93fc0eb5d6b75ad63f8c4f8b3a0ec42cb6d886a0d82"
                      >
                        <header>
                          <h3 class="trip-head">Process</h3>
                        </header>

                        <div class="item-list">
                          <ul class="plan-trip-list">
                            <li>
                              <div class="icon">
                                <img
                                  src="https://www.fortishealthcare.com/drupal-data/2023-05/question%20%284%29.svg"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                              <div class="title">General Enquiry</div>
                            </li>
                            <li>
                              <div class="icon">
                                <img
                                  src="https://www.fortishealthcare.com/drupal-data/2023-05/chat-4%20%284%29.svg"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                              <div class="title">
                                Medical opinion by experts
                              </div>
                            </li>
                            <li>
                              <div class="icon">
                                <img
                                  src="https://www.fortishealthcare.com/drupal-data/2023-05/credit-card%20%287%29.svg"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                              <div class="title">Visa assistance</div>
                            </li>
                            <li>
                              <div class="icon">
                                <img
                                  src="https://www.fortishealthcare.com/drupal-data/2023-05/calendar-4%20%283%29.svg"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                              <div class="title">Booking, Arrival</div>
                            </li>
                            <li>
                              <div class="icon">
                                <img
                                  src="https://www.fortishealthcare.com/drupal-data/2023-05/doctor-5%20%285%29.svg"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                              <div class="title">
                                Pre-Operative Consultation
                              </div>
                            </li>
                            <li>
                              <div class="icon">
                                <img
                                  src="https://www.fortishealthcare.com/drupal-data/2023-05/knife-and-scissor%20%285%29.svg"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                              <div class="title">Treatment</div>
                            </li>
                            <li>
                              <div class="icon">
                                <img
                                  src="https://www.fortishealthcare.com/drupal-data/2023-05/stay-healthy%20%284%29.svg"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                              <div class="title">Recuperation</div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="guidelines">
                    <h2 class="heading2">Guidelines</h2>
                    <ul class="guidelines-tabs common-tabs">
                      <li data-tab="checklist-section" class="current">
                        Checklist
                      </li>
                      <li data-tab="payment-advisory">Payment Advisory</li>
                    </ul>
                    <div class="guidelines-content common-tabs-outer">
                      <ul
                        class="checklist-section common-tabs-content current"
                        id="checklist-section"
                      >
                        <li>
                          <ul class="checklist">
                            <li class="checklist-row">
                              Identity Proof/Passport/Visa copy
                            </li>
                            <li class="checklist-row">Insurance card</li>
                            <li class="checklist-row">
                              Any referral notes from the previous doctor
                            </li>
                            <li class="checklist-row">
                              Passport size photographs (10) of the Patients as
                              well as the attendant.
                            </li>
                            <li class="checklist-row">
                              Recent medical reports (including scans, tissue
                              block slides, X-rays, blood tests etc.)
                            </li>
                            <li class="checklist-row">
                              A detailed report and prescriptions of the ongoing
                              drugs
                            </li>
                            <li class="checklist-row">
                              In case of an organ transplant, Organ transplant
                              coordinator will assist with list of documents
                            </li>
                          </ul>
                        </li>
                      </ul>
                      <ul
                        class="payment-advisory common-tabs-content"
                        id="payment-advisory"
                      >
                        <li>
                          <div class="guidelines-desc">
                            <p>
                              <strong>Payment/Forex Advisory:&nbsp;</strong>
                            </p>
                            <p><strong>&nbsp;</strong></p>
                            <p>
                              The mode of payment will be
                              <strong
                                >either cash or bank transfer or international
                                credit/debit card</strong
                              >. 100 % payment needs to be deposited before
                              surgery/procedure/investigations.&nbsp;
                            </p>
                            <p><strong>&nbsp;</strong></p>
                            <ul>
                              <li>
                                You are required to share the transfer receipt
                                with us if opted for wire transaction as it
                                takes 7 to 10 working days to shown up in our
                                account. Hence, it is recommended to transfer
                                the amount at least 10 days prior to the
                                arrival.&nbsp;
                              </li>
                            </ul>
                            <p><strong>&nbsp;</strong></p>
                            <ul>
                              <li>
                                Please note, as per Government of India foreign
                                exchange rules (FEMA), all patients /passengers
                                travelling to India and carrying currency more
                                than <strong>USD 5000</strong> are required to
                                declare the same as per the
                                <strong>Customs Declaration Form (CDF)</strong>
                                and should carry with them the CDF as proof of
                                currency brought in to the country.&nbsp;
                              </li>
                            </ul>
                            <p>&nbsp;</p>
                            <ul>
                              <li>
                                CDF is available at the airport Custom
                                office.&nbsp;
                              </li>
                            </ul>
                            <p>&nbsp;</p>
                            <ul>
                              <li>
                                Any medical procedure costing above
                                <strong>USD 5000</strong>, we would request or
                                prefer all funds to be transferred directly to
                                the account of respective unit of Medanta
                                Healthcare.&nbsp;
                              </li>
                            </ul>
                            <p>&nbsp;</p>
                            <ul>
                              <li>
                                Any amount can be accepted in foreign currency
                                with declared value as per CDF&nbsp;
                              </li>
                            </ul>
                            <p>&nbsp;</p>
                            <ul>
                              <li>
                                In absence of CDF, foreign currency
                                <strong>USD 5000</strong> can only be accepted
                                at the hospital in cash.&nbsp;
                              </li>
                            </ul>
                          </div>
                          <ul class="press-release-section"></ul>
                        </li>
                      </ul>
                      <ul
                        class="safety-measures common-tabs-content"
                        id="safety-measures"
                      >
                        <li>
                          <ul class="press-release-section"></ul>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="views-element-container">
                  <div
                    class="patient-section section-empty patient-section-international js-view-dom-id-0030f84faa452f6010ef9374a6b6199456308b4929df155c998a07e5389b65d8"
                  >
                    <header>
                      <div class="head-row">
                        <h3 class="heading2">Patient Speaks</h3>
                      </div>
                    </header>

                    <div class="patient-right">
                      <ul class="patient-slider">
                        <li class="patient-box">
                          <div class="patient-left">
                              <img src="assets/google.webp" >
                            <div class="p-name-date"></div>
                          </div>
                          <div class="patient-text">
                            <div class="patient-description">
                              <p>
                                "Exceptional Pediatric Care - My son received pediatric care at ConviCare for a congenital heart condition. The compassion and expertise shown by the pediatric team were beyond what we had hoped for. We felt supported every step of the way, and my son is now doing wonderfully."
                              </p>
                            </div>
                            <div class="patient-location">
                              <div class="patient-hospital">
                                <span> Medanta Hospital</span>
                              </div>
                            </div>
                          </div>
                        </li>
                        <li class="patient-box">
                          <div class="patient-left">
                            <img src="assets/google.webp" >
                            <div class="p-name-date"></div>
                          </div>
                          <div class="patient-text">
                            <div class="patient-description">
                              <p>
                                "Innovative Neurosurgery Techniques - I traveled to ConviCare for minimally invasive neurosurgery that wasn’t available in my country. The neurosurgeons at ConviCare are truly at the forefront of their field. The care I received was top-notch, and my recovery has been faster than anticipated."
                              </p>
                            </div>
                            <div class="patient-location">
                              <div class="patient-hospital">
                                <span> Medanta Hospital</span>
                              </div>
                            </div>
                          </div>
                        </li>
                        <li class="patient-box">
                          <div class="patient-left">
                            <img src="assets/google.webp" >
                            <div class="p-name-date"></div>
                          </div>
                          <div class="patient-text">
                            <div class="patient-description">
                              <p>
                                "Comprehensive Diabetes Management - As a long-time diabetes sufferer, the comprehensive approach at ConviCare has changed my life. Their endocrinology department helped me manage my diabetes like never before. The staff’s dedication to patient education and personalized care plans is commendable."
                              </p>
                            </div>
                            <div class="patient-location">
                              <div class="patient-hospital">
                                <span>
                                  Medanta Hospital
                                </span>
                              </div>
                            </div>
                          </div>
                        </li>
                        
                        <li class="patient-box">
                          <div class="patient-left">
                            <img src="assets/google.webp" >
                            <div class="p-name-date"></div>
                          </div>
                          <div class="patient-text">
                            <div class="patient-description">
                              <p>
                                "Advanced Oncology Treatment - Dealing with cancer is challenging, but ConviCare’s Oncology department provided me with cutting-edge treatment options and genuine care. Their holistic approach to cancer treatment, including support services, made a difficult time much easier to handle."
                              </p>
                            </div>
                            <div class="patient-location">
                              <div class="patient-hospital">
                                <span>
                                  Medanta Hospital
                                </span>
                              </div>
                            </div>
                          </div>
                        </li>
                        
                        <li class="patient-box">
                          <div class="patient-left">
                            <img src="assets/google.webp" >
                            <div class="p-name-date"></div>
                          </div>
                          <div class="patient-text">
                            <div class="patient-description">
                              <p>
                                "Expertise in Transplant Surgery - My liver transplant at ConviCare was a success thanks to their highly skilled transplant team and the excellent post-operative care. The hospital’s infrastructure and patient care protocols are designed to support a full recovery and optimal outcomes."
                              </p>
                            </div>
                            <div class="patient-location">
                              <div class="patient-hospital">
                                <span>
                                  Medanta Hospital
                                </span>
                              </div>
                            </div>
                          </div>
                        </li>
                        <!--<li class="patient-box">-->
                        <!--  <div class="patient-left">-->
                        <!--    <div class="patient-img">-->
                        <!--      <div class="play-btn"></div>-->
                        <!--      <iframe-->
                        <!--        loading="lazy"-->
                        <!--        width="168"-->
                        <!--        height="168"-->
                        <!--        src=""-->
                        <!--        frameborder="0"-->
                        <!--        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"-->
                        <!--        allowfullscreen-->
                        <!--      ></iframe>-->
                        <!--    </div>-->
                        <!--    <div class="p-name-date"></div>-->
                        <!--  </div>-->
                        <!--  <div class="patient-text">-->
                        <!--    <div class="patient-description">-->
                        <!--      <p>-->
                        <!--        "Beyond Expectations" - "I came to Fortis for a knee replacement and was amazed by the advanced technology and expertise available. The surgeons and nurses are highly skilled, and the recovery was much faster than anticipated. The personalized care made a significant difference."-->
                        <!--      </p>-->
                        <!--    </div>-->
                        <!--    <div class="patient-location">-->
                        <!--      <div class="patient-hospital">-->
                        <!--        <span> Fortis Hospital, Mulund, Mumbai </span>-->
                        <!--      </div>-->
                        <!--    </div>-->
                        <!--  </div>-->
                        <!--</li>-->
                      </ul>
                    </div>
                  </div>
                </div>

                <div class="int-about-us">
                  <div class="views-element-container">
                    <div
                      class="about-us-main section-empty js-view-dom-id-9c6fbb9681dba72bd6289c6ba6c0e14b5dbedd6fc883a401586b9be2b915dde6"
                    >
                      <header>
                        <h3 class="heading2">
                          Why Choose Medanta?
                        </h3>
                      </header>

                      <div>
                        <div class="about-us-wrap">
                          <div class="img">
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/styles/inet_about_us407_219/azblob/2024-03/Cover%20Design%20Option%201.jpg?itok=1CthwlqN"
                              width="407"
                              height="219"
                              alt="Fortis International Hospitals- Healthcare of International Standards within the reach of each"
                              loading="lazy"
                            />
                          </div>
                          <div class="text readmore-section">
                              Pioneering Medical Excellence: Since our inception, we have been at the forefront of medical innovation, providing cutting-edge treatments and the highest level of patient care.
                              <br><br>
                              <p><b style="font-weight:bold;">State-of-the-Art Facilities: </b>Spread over 43 acres, Medanta houses several specialty centers making it a premier destination for advanced medical care.</p>
                              <br>
                              <p><b style="font-weight:bold;">Global Patient Care: </b>Our dedicated International Patient Services team ensures that patients from all over the world receive personalized and compassionate care throughout their medical journey.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                
                
                <div class="int-partner-logo">
                  <div class="views-element-container">
                    <div
                      class="international-logo-view section-empty js-view-dom-id-fec9c1b4cdb13d87c240c0c477368ea6cb433d3700da65fb1c83171842cb2166"
                    >
                      <header>
                        <div class="head-row">
                          <h3 class="heading2">
                            Our International Insurance Partners
                          </h3>
                          
                        </div>
                      </header>

                      <div class="item-list">
                        <ul class="international-logo-list">
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/Aetna.png"
                              width="516"
                              height="98"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/Allianz%20Partner.png"
                              width="505"
                              height="100"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/ARMS.png"
                              width="300"
                              height="86"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/Assist%20Card.png"
                              width="512"
                              height="512"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/ATMS.png"
                              width="366"
                              height="137"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/Wellbe.jpg"
                              width="512"
                              height="250"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/Falck.jpg"
                              width="537"
                              height="185"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/East-west-rescue.jpg"
                              width="280"
                              height="314"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/Paramount.png"
                              width="281"
                              height="250"
                              alt="IMG"
                              loading="lazy"
                            />
                          </li>
                          <li>
                            <img
                              src="https://www.fortishealthcare.com/drupal-data/2023-05/Prestige%20International.png"
                              width="512"
                              height="288"
                              alt="img"
                              loading="lazy"
                            />
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="int-faqs">
                  <div class="views-element-container">
                    <div
                      class="faq-outer section-empty js-view-dom-id-813fc951f8a1d6a858eff298d52b3d92567ef8e9b4b5d5a21c9e0670a3c651c3"
                    >
                      <header>
                        <div class="head-row">
                          <h3 class="heading2">FAQ's</h3>
                          
                        </div>
                      </header>

                      <div class="item-list">
                        <ul class="faq-sec">
                            
                            <li>
                              <h4 class="faq-title">
                                How do I schedule an appointment from abroad?
                              </h4>
                              <div class="faq-content">
                                <p>
                                  Contact our International Patient Services team via email or phone. We will guide you through the process and arrange everything from initial consultations to your travel plans.
                                </p>
                              </div>
                            </li>
                            
                            <li>
                              <h4 class="faq-title">
                                What are the accommodation options?
                              </h4>
                              <div class="faq-content">
                                <p>
                                  We offer a range of accommodations from hospital-adjacent guest houses to luxury hotels that partner with Medanta for our international patients.
                                </p>
                              </div>
                            </li>
                            
                            <li>
                              <h4 class="faq-title">
                                Can family members accompany me?
                              </h4>
                              <div class="faq-content">
                                <p>
                                  Absolutely. We ensure your companions are comfortable and well-accommodated during your treatment period.
                                </p>
                              </div>
                            </li>
                            
                            <li>
                              <h4 class="faq-title">
                                How can I make payments from overseas?
                              </h4>
                              <div class="faq-content">
                                <p>
                                  Payments can be made via international wire transfers, major credit cards, or direct bank transfers. We provide all necessary banking details upon request.
                                </p>
                              </div>
                            </li>
                            
                            <li>
                              <h4 class="faq-title">
                                What should I bring for my treatment?
                              </h4>
                              <div class="faq-content">
                                <p>
                                  Please bring your medical records, identification documents, relevant medical prescriptions, and personal necessities. Our team will provide a detailed checklist when you schedule your treatment.
                                </p>
                              </div>
                            </li>

                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="moderation-form-sec"></div>
            </div>
          </div>
        </div>
        
        <div class="fixed-bottom-bar">
            <a class="help-button" href="#contact-form">
                <img style="max-width:20px;margin-right: 10px;filter: brightness(0) invert(1);" src="assets/phone-call.png" alt="search">
                Need Help?
            </a>
            <a class="chat-button" href="https://api.whatsapp.com/send?phone=919990007484&text=Hello%2C%20I%E2%80%99m%20planning%20medical%20travel%20to%20India%20and%20would%20like%20to%20know%20more%20about%20treatment%20options%20at%20Medanta%20Hospital.%20Could%20you%20assist%20me%3F">
                <img style="max-width:22px;margin-right: 10px;" src="assets/whatsapp-icon.png" alt="search">
                Whatsapp
            </a>
        </div>

        <!-- Content ENDS -->

        <!-- Page Top ENDS -->
        <!-- Page Top STARTS -->
      </main>

      <!-- FOOTER START -->
      <footer class="footer">
        <!-- FOOTER  TOP START -->
        

        <!-- FOOTER  TOP END -->
        <!-- FOOTER BOTTOM START -->
        <div class="footer-bottom">
          <div class="wrapper">
            <div class="footer-bottom-inner">
              <!-- FOOTER LEFT START -->
              <div class="footer-bottom-left">
                <div>
                  <div id="block-footerbottomlogo">
                    <div class="layout layout--onecol">
                      <div class="layout__region layout__region--content">
                        <div>
                          <div class="footer-logo">
                            <img
                              src="https://www.convicare.com/images/covicare-logo-1-1-min-oqa8jt5nw1lzjb0500f10bz3juopxz6ut7v2slau52.png"
                              alt="footer logo"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- FOOTER LEFT END -->
              <!-- FOOTER CENTRE START -->
              <div class="footer-social-outer">
                <div>
                  <div id="block-footersocialblock">
                    <div class="layout layout--onecol">
                      <div class="layout__region layout__region--content">
                        <div>
                          <h4>STAY IN TOUCH</h4>
                          <div class="footer-social">
                            <a
                              href="#"
                              target="_blank"
                            >
                              <img
                                src="https://fhlazwebsau01.blob.core.windows.net/drupal-data/2023-03/instagrame.png"
                                alt="instagram"
                            /></a>
                            <a
                              href="#"
                              target="_blank"
                              ><img
                                src="https://fhlazwebsau01.blob.core.windows.net/drupal-data/2023-03/facebook.png"
                                alt="facebook"
                            /></a>
                            <a
                              href="#"
                              target="_blank"
                              ><img
                                src="https://fhlazwebsau01.blob.core.windows.net/drupal-data/2023-03/twitter.png"
                                alt="twitter"
                            /></a>
                            <a
                              href="#"
                              target="_blank"
                              ><img
                                src="https://fhlazwebsau01.blob.core.windows.net/drupal-data/2023-03/youtube.png"
                                alt="youtube"
                            /></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- FOOTER CENTRE END -->
              <!-- FOOTER RIGHT START -->
              <div class="footer-link-outer">
                <div>
                  <nav
                    role="navigation"
                    aria-labelledby="block-footer-menu"
                    id="block-footer"
                    class="footer-link"
                  >
                    <h2 class="visually-hidden" id="block-footer-menu">
                      Footer
                    </h2>

                    
                  </nav>
                  <div id="block-footerbottomcopyrightblock">
                    <div class="layout layout--onecol">
                      <div class="layout__region layout__region--content">
                        <div>
                          <p>2024 Convicare. All Rights Reserved.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- FOOTER RIGHT END -->
            </div>
          </div>
        </div>
      </footer>
      <!-- FOOTER END -->
    </div>

    <div class="popup-outer video-popup">
      <div class="popup-sec">
        <div class="close-video"></div>
        <iframe
          title="Window"
          loading="lazy"
          width="900"
          height="506"
          src=""
          frameborder="0"
          allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
        ></iframe>
        <video
          class="video-mp4"
          width="900"
          height="506"
          controls
          src=""
          type="video/mp4"
        >
          Browser not supported
        </video>
      </div>
    </div>

    <script
      data-cfasync="false"
      src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script type="application/json" data-drupal-selector="drupal-settings-json">
      {
        "path": {
          "baseUrl": "\/",
          "scriptPath": null,
          "pathPrefix": "",
          "currentPath": "node\/11683",
          "currentPathIsAdmin": false,
          "isFront": false,
          "currentLanguage": "en"
        },
        "pluralDelimiter": "\u0003",
        "suppressDeprecationErrors": true,
        "ajaxPageState": {
          "libraries": "core\/internal.jquery.form,file\/drupal.file,fortis\/global-request-callback,fortis\/global-scripts,fortis\/international-styling,fortis_contact\/feedback_query_form,fortis_doctor_details\/datepicker_lib,fortis_international\/fortis-international,fortis_search\/fortis-search-autocomplete,layout_discovery\/onecol,system\/base,views\/views.module",
          "theme": "fortis",
          "theme_token": null
        },
        "ajaxTrustedUrl": {
          "form_action_p_pvdeGsVG5zNF_XLGPTvYSKCf43t8qZYSwcfZl2uzM": true,
          "\/international-patients?ajax_form=1": true,
          "\/international-patients?element_parents=speciality_file_wrapper\/upload_file\u0026ajax_form=1": true,
          "\/search": true
        },
        "ajax": {
          "edit-submit": {
            "callback": "::getAnestimateSubmitAjax",
            "event": "click",
            "progress": {
              "type": "throbber"
            },
            "url": "\/international-patients?ajax_form=1",
            "dialogType": "ajax",
            "submit": {
              "_triggering_element_name": "op",
              "_triggering_element_value": "Get An Estimate"
            }
          },
          "edit-upload-file-upload-button": {
            "callback": [
              "Drupal\\file\\Element\\ManagedFile",
              "uploadAjaxCallback"
            ],
            "wrapper": "ajax-wrapper",
            "effect": "fade",
            "progress": {
              "type": "throbber",
              "message": null
            },
            "event": "mousedown",
            "keypress": true,
            "prevent": "click",
            "url": "\/international-patients?element_parents=speciality_file_wrapper\/upload_file\u0026ajax_form=1",
            "dialogType": "ajax",
            "submit": {
              "_triggering_element_name": "upload_file_upload_button",
              "_triggering_element_value": "Upload"
            }
          }
        },
        "file": {
          "elements": {
            "#edit-upload-file-upload": "pdf,jpg,jpeg,png"
          }
        },
        "fortis_doctor_details": {
          "no_result_msg": "Looks like there are no matching results for this filter."
        },
        "fortis": {
          "ag": true,
          "locationDropdown": false
        },
        "user": {
          "uid": 0,
          "permissionsHash": "1c1b1d5b76a66a047c71ab96f38ef955f25227dce423900a7462cd8ceea5a2c8"
        }
      }
    </script>
    <script src="sites/default/files/js/js_rh3fZ05ZNf9awWZOZwZwjTAhAXz8pjlAHVo1eg6PN4k.js"></script>
    <script src="sites/default/files/js/js_cT8MeBAdCNQyRnEn0l7Od-pNHW4ypLAuY-AeXSfBYRY.js"></script>
    <script src="sites/default/files/js/js_zTIUREatI-kJp400NMaJ6RP2FDmsNr3BAPemG_JNfbA.js"></script>
    <script src="sites/default/files/js/js_NRRUZeL7Cix-5oZNRT7rvq1oGslATZ3-showFGuHUro.js"></script>
    
    <script>
            function limitNumberLength(input, maxLength) {
                if (input.value.length > maxLength) {
                    input.value = input.value.slice(0, maxLength);
                }
            }
        </script>

    <!--<script>-->
    <!--  Defer.js(-->
    <!--    "https://www.googletagmanager.com/gtag/js?id=AW-943766008",-->
    <!--    "googleoptimize",-->
    <!--    3500-->
    <!--  );-->
    <!--  Defer.js(-->
    <!--    "https://www.googletagmanager.com/gtag/js?id=UA-17184833-1",-->
    <!--    "googleoptimize",-->
    <!--    3500-->
    <!--  );-->
    <!--</script>-->
    
    <a
      data-dialog-type="modal"
      data-dialog-options='{"dialogClass":"request-callback-popup form-position"}'
      class="button use-ajax request-callback hide"
      href="/request-callback-popup"
      >Request callback
    </a>
    <script
      defer
      src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
      integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
      data-cf-beacon='{"rayId":"8d409fab8e218566","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"version":"2024.10.1","token":"73f660d192c94dd292746e0c3ba104d5"}'
      crossorigin="anonymous"
    ></script>
  </body>
</html>
